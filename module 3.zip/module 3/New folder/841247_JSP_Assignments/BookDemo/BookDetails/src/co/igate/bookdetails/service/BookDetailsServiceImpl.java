package co.igate.bookdetails.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.igate.bookdetails.bean.BookDetailsBean;
import com.igate.bookdetails.dao.BookDetailsDaoImpl;
import com.igate.bookdetails.dao.IBookDetailsDao;
import com.igate.bookdetails.exception.MyException;

public class BookDetailsServiceImpl implements IBookDetailsService 
{
	IBookDetailsDao dao=new BookDetailsDaoImpl();
	@Override
	public boolean isValid(String isbn)throws MyException
	{
		Pattern pattern1=Pattern.compile("^[0-9]+$");
		Matcher match=pattern1.matcher(isbn);
		if(!match.find())
		{
			throw new MyException("Should be a Positive Number");
		}
		return true;
	}

	@Override
	public String getDetails(int locIsbn) throws MyException 
	{
		
		String bookName=dao.getConection(locIsbn);
		return bookName;
	}
	
	public void displayDetails(BookDetailsBean bean) throws MyException
	{
		dao.displayDetails(bean);
	}

	@Override
	public int isValidDays(int isbn) throws MyException 
	{
		int locDays=dao.isValidDays(isbn);
		return locDays;
	}
}
