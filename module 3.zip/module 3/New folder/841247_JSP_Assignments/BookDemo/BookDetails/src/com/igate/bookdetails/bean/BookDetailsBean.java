package com.igate.bookdetails.bean;

public class BookDetailsBean 
{
	public int getBookIsbn() {
		return bookIsbn;
	}
	public void setBookIsbn(int bookIsbn) {
		this.bookIsbn = bookIsbn;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public BookDetailsBean(int bookIsbn, String description, int noOfDays) {
		super();
		this.bookIsbn = bookIsbn;
		this.description = description;
		this.noOfDays = noOfDays;
	}
	private int bookIsbn;
	private String description;
	private int noOfDays;
	
}
