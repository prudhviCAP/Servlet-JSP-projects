package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class ComfirmServlet
 */
@WebServlet("/ConfirmServlet")
public class ConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession ses=request.getSession();
		PrintWriter out=response.getWriter();
		String name=(String)ses.getAttribute("name");
	
		
		String startHtml="<html><head></head><body>";
		String endHtml="</body></html>";
		out.println(startHtml+"<b>Welcome....."+name+"</b></br>"
				+ "<center><form action='Login.html' method='get'><table border=\"1\">"+
				"<thead>"+
				"<tr>"+
				"<th> Item Id </th>"+
				"<th> Item Name </th>"+
				"<th> ItemPrice </th>"+
			
				"</tr>"+	
				"</thead>");
		IAuctionService implObj=new AuctionServiceImpl();
		try {
			HttpSession session=request.getSession();
			Map<String, AuctionBean> mapAuction=(Map<String, AuctionBean>)session.getAttribute("biddingCart");
			double total=0;
			
			Set <Entry<String,AuctionBean>> value=mapAuction.entrySet();
			Iterator<Entry<String, AuctionBean>> itr=value.iterator();
			while(itr.hasNext())
			{	
				System.out.println("here");
				Map.Entry<String,AuctionBean> me=(Entry<String, AuctionBean>)itr.next();
				AuctionBean aBean = (AuctionBean) me.getValue();
				if(mapAuction!=null)
				{
					String	strPrice=aBean.getItemPrice();
					String strItem=aBean.getItemId();
					double price=Double.parseDouble(strPrice);
						out.println("<tbody>"+
						"<tr>"+
						"<td>"+aBean.getItemId()+"</td>"+
						"<td>"+aBean.getItemName()+"</td>"+
						"<td>"+price+"</td>");
					total+=price;
					implObj.updateDBService(strItem);
				}
				out.println("</tr>");
			}
			out.println("<tr ><td colspan=2><input type=\"submit\" value=\"Logout\"></td></tr></tbody>");
			out.println("Final price---------------"+total);

			out.println("</table></form></center>");
		} catch (MyException e) {
		
			
		}
		out.println(endHtml);
	}

}
