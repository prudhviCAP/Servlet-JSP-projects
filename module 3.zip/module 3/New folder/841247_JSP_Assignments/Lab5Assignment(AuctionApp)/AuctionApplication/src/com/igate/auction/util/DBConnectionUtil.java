package com.igate.auction.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.igate.auction.exception.MyException;


/*
 * DBUtil class to access a connection pool 
 */
public class DBConnectionUtil {
	static Connection connection;

	public static Connection obtainConnection() throws MyException {
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context
					.lookup("java:/OracleDS");
			connection = source.getConnection();
		} catch (NamingException e) {
			throw new MyException("Error while creating datascource::"
					+ e.getMessage());
		} catch (SQLException e) {
			throw new MyException("Error while obtaining connection::"
					+ e.getMessage());
		}
		return connection;
	}
}
