package com.igate.auction.dao;


import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;

public interface IAuctionDAO {
	boolean getLoginDetails(String username,String password) throws MyException;
	Map<Integer, ItemsBean> getItemsDetails() throws MyException;
	Map<Integer, ItemsBean> updateStatus(int itemId) throws MyException;
	void updateDB(int itemId) throws MyException;
}
