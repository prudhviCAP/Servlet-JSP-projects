package com.igate.auction.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.dao.AuctionDAOImpl;
import com.igate.auction.dao.IAuctionDAO;
import com.igate.auction.exception.MyException;

public class AuctionServiceImpl implements IAuctionService {

	@Override
	public boolean getLoginDetails(String username, String password)
			throws MyException {
		IAuctionDAO dao=new AuctionDAOImpl();
		boolean login=dao.getLoginDetails(username, password);
		return login;
	}

	@Override
	public Map<Integer, ItemsBean> getItemsDetails() throws MyException {
		IAuctionDAO dao=new AuctionDAOImpl();
		Map<Integer, ItemsBean> map=dao.getItemsDetails();
		return map;
	}


	@Override
	public Map<Integer, ItemsBean> updateStatus(int itemId) throws MyException {
		IAuctionDAO dao=new AuctionDAOImpl();
		Map<Integer, ItemsBean> map=dao.updateStatus(itemId);
		return map;
	}

	@Override
	public void updateDB(int itemId) throws MyException {
		IAuctionDAO dao=new AuctionDAOImpl();
		dao.updateDB(itemId);
		
	}

	

}
