package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class BiddingCart
 */
@WebServlet("/BiddingCart")
public class BiddingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	Map<Integer, ItemsBean> map=new HashMap<>();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAuctionService service=new AuctionServiceImpl();
		HttpSession session=request.getSession();
		
		PrintWriter pw=response.getWriter();
		String id1=request.getParameter("id1");
		int id2=Integer.parseInt(id1);
		
		
		
		
		try {
			pw.println("Welcome......."+request.getParameter("userName"));
			Map<Integer, ItemsBean> map=service.updateStatus(id2);
			Iterator<ItemsBean> itr=map.values().iterator();
			pw.println("<html><body><form action='FinalCart' name='form1'>");
			pw.println("<table border=1 align='center' id='myTable'>");
			pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th><th>Item Status</th><th>Remove</th>");
			pw.println("</tr>");
			
			while(itr.hasNext()) {
				ItemsBean bean=itr.next();
				int id=bean.getItemId();
				String itemName=bean.getItemName();
				double price=bean.getItemPrice();
				String status=bean.getItemStatus();
				System.out.println(id);
				pw.println("<tr>");
		
				pw.println("<td>"+id+"</td>");
				pw.println("<td>"+itemName+"</td>");
				pw.println("<td>"+price+"</td>");
				pw.println("<td>"+status+"</td>");
				pw.println("<td><a href='#'>Remove from bidding cart</a></td>");
				//pw.println("<td><input type='button' value='Remove from bidding cart' onclick='"+map.remove(id)+"'></td>");
				pw.println("</tr>");
			}
			pw.println("</table>");
			pw.println("<input type='button' name='confirm' value='Confirm Bidding' align='center'>");
			pw.println("<a href='SuccessController'>Go Back to Original Bidding Items List</a>");
			//map.remove(Integer.parseInt(request.getParameter("name")));
			pw.println("</form></body><html>");
		} catch (MyException e) {
			
		}
		
		
	}


}
