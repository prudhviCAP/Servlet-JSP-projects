package com.igate.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.util.DBUtil;


public class AuctionDAOImpl implements IAuctionDAO {

	//Set<ItemsBean> set=new LinkedHashSet<>();
	//Set<ItemsBean> set1=new LinkedHashSet<>();
	Map<Integer, ItemsBean> map=new HashMap<Integer, ItemsBean>();
	Map<Integer, ItemsBean> map1=new HashMap<Integer, ItemsBean>();
	@Override
	public boolean getLoginDetails(String username, String password)
			throws MyException {
		Connection con=DBUtil.obtainConnection();
		PreparedStatement pstat=null;
		ResultSet rset=null;
		boolean flag=false;
		String query="Select * from login where username=? and password=?";
		try {
			pstat=con.prepareStatement(query);
			pstat.setString(1, username);
			pstat.setString(2, password);
			rset=pstat.executeQuery();
			flag=rset.next();
		} catch (SQLException e) {
			throw new MyException("Unable to process the query");
		}
		return flag;
	}

	@Override
	public Map<Integer, ItemsBean> getItemsDetails() throws MyException {
		Connection con=DBUtil.obtainConnection();
		ItemsBean bean=null;
		PreparedStatement pstat=null;
		ResultSet rset=null;
		
		try {
			String query="select * from itemsforbid";
			pstat=con.prepareStatement(query);
			rset=pstat.executeQuery();
			while(rset.next()) {
				int id=rset.getInt("itemid");
				String itemName=rset.getString("itemname");
				double price=rset.getDouble("itemprice");
				String status=rset.getString("itemstatus");
				bean=new ItemsBean(id, itemName, price, status);
				map.put(id, bean);
			}
		} catch (SQLException e) {
			throw new MyException("Unable to process the query");
		}
		return map;
	}

	@Override
	public Map<Integer, ItemsBean> updateStatus(int itemId) throws MyException {
		Connection con=DBUtil.obtainConnection();
		ItemsBean bean=null;
		PreparedStatement pstat=null;
		ResultSet rset=null;
		
		try {
			String query="select * from itemsforbid where itemid=?";
			pstat=con.prepareStatement(query);
			pstat.setInt(1, itemId);
			rset=pstat.executeQuery();
			while(rset.next()) {
				int id=rset.getInt("itemid");
				String itemName=rset.getString("itemname");
				double price=rset.getDouble("itemprice");
				String status=rset.getString("itemstatus");
				bean=new ItemsBean(id, itemName, price, status);
				map1.put(id, bean);
			}
		} catch (SQLException e) {
			throw new MyException("Unable to process the query");
		}
		return map1;
	}

	@Override
	public void updateDB(int itemId) throws MyException {
		Connection con=DBUtil.obtainConnection();
		PreparedStatement pstat=null;
		
		String query="update itemsforbid set itemstatus='not available' where itemid=?";
		try {
			pstat=con.prepareStatement(query);
			pstat.setInt(1, itemId);
			pstat.executeUpdate();
			//con.commit();
		} catch (SQLException e) {
			throw new MyException("Unable to process the query");
		}
	}
	
}
