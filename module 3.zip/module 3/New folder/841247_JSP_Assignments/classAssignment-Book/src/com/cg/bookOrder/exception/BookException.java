package com.cg.bookOrder.exception;

public class BookException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookException(String errMsg)
	{
		super(errMsg);
	}
	

}
