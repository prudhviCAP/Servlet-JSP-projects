package com.cg.bookOrder.util;
	import java.sql.Connection;
	import java.sql.SQLException;

	import javax.naming.InitialContext;
	import javax.naming.NamingException;
	import javax.sql.DataSource;

	import com.cg.bookOrder.exception.BookException;

	public class DBConnectionUtil {
		static Connection connection;

		public static Connection obtainConnection() throws BookException{
			try {
				InitialContext context = new InitialContext();
				DataSource source = (DataSource) context
						.lookup("java:/OracleDS");
				connection = source.getConnection();
			} catch (NamingException e) {
				throw new BookException("An error occurred while creating datasource"+e);
				
			} catch (SQLException e) {
				
				throw new BookException("Cannot connect to the database"+e);
			}
			return connection;
		}
	}
	

