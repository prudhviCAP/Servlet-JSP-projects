package com.cg.bookOrder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.bookOrder.bean.Book;
import com.cg.bookOrder.exception.BookException;
import com.cg.bookOrder.util.DBConnectionUtil;

public class BookOrderDaoImpli implements IBookOrderDao{

	Connection con=null;
	PreparedStatement prpstmt=null;
	ResultSet res=null;

	@Override
	public String getName(int isbn) throws BookException {
		con=DBConnectionUtil.obtainConnection();
		String SELECTQUERY="SELECT book_name from  book_details where bookISBN=?";
		try {
			prpstmt=con.prepareStatement(SELECTQUERY);
			prpstmt.setInt(1, isbn);
			int count=prpstmt.executeUpdate();
			res=prpstmt.executeQuery();
			String name=null;
			if(count<=0)
			{
				throw new BookException("No rows selected....Enter proper ISBN number");
			}
			else
			{
				while(res.next())
				{
					name=res.getString(1);
				}
				return name;
			}
		} catch (SQLException e) {
			throw new BookException("Error while selecting values from database...ERROR MESSAGE::"+e.getMessage());
		}
		finally
		{
			try{
				if(con!=null)
				{
					if(prpstmt!=null)
					{
						if(res!=null)
						{
							res.close();
						}
						prpstmt.close();
					}
					con.close();
				}
			}catch(SQLException e)
			{
				throw new BookException("Could not close the connection");
			}
		}
	}

	@Override
	public boolean validateDay(int noOfdays,int isbn) throws BookException {

		con=DBConnectionUtil.obtainConnection();

		try{
			String SELECTQUERY="SELECT min_shipment_days from  book_details where bookISBN=?";
			prpstmt=con.prepareStatement(SELECTQUERY);
			prpstmt.setInt(1, isbn);

			res=prpstmt.executeQuery();
			int minShipmentDays=0;


			while(res.next())
			{
				minShipmentDays=res.getInt(1);
			}
			if(noOfdays<minShipmentDays)
			{
				throw new BookException("The no of days entered is less for the book to be delivered"
						+ "....Please enter another greater value");

			}
			else
				return true;
		}catch(SQLException e)
		{
			throw new BookException("ERROR WHILE SELECTING THE BOOKS... "+e.getMessage());
		}
		finally
		{
			try{
				if(con!=null)
				{
					if(prpstmt!=null)
					{
						if(res!=null)
						{
							res.close();
						}
						prpstmt.close();
					}
					con.close();
				}
			}catch(SQLException e)
			{
				throw new BookException("Could not close the connection");
			}
		}
		
	}

	@Override
	public int updateBookOrder(Book book) throws BookException {

		con=DBConnectionUtil.obtainConnection();
		String INSERTQUERY="INSERT INTO book_shipment_details VALUES(?,?,?,?,?)";
		try{
			prpstmt=con.prepareStatement(INSERTQUERY);
			prpstmt.setInt(1, book.getIsbn());
			prpstmt.setDate(2,java.sql.Date.valueOf(book.getStartDate()));
			prpstmt.setDate(3,java.sql.Date.valueOf(book.getEndDate()));
			prpstmt.setString(4, book.getDescription());
			prpstmt.setInt(5, book.getMinShipmentDays());

			int updateRes=prpstmt.executeUpdate();
			if(updateRes<=0)
			{
				throw new BookException("could not update the database");
			}
			return updateRes;
		}catch(SQLException e)
		{
			throw new BookException(e.getMessage());
		}
		finally
		{
			try{
				if(con!=null)
				{
					if(prpstmt!=null)
					{
						if(res!=null)
						{
							res.close();
						}
						prpstmt.close();
					}
					con.close();
				}
			}catch(SQLException e)
			{
				throw new BookException("Could not close the connection");
			}
		}

	}

}


