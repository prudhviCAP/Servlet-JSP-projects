package com.igate.assignment.service;

import java.util.List;

import com.igate.assignment.dto.Employee;
import com.igate.lab1.exception.MyException;

public interface IEmployeeService {
	List<Employee> getDetails(String id,String text) throws MyException;
	StringBuilder isValid(String id,String text);
}
