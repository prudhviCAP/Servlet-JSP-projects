package com.igate.assignment.dto;

public class Employee {
	private int eid;
	private String name;
	private int deptid;
	private int salary;
	private String location;
	public Employee(int eid, String name, int deptid, int salary,
			String location) {
		super();
		this.eid = eid;
		this.name = name;
		this.deptid = deptid;
		this.salary = salary;
		this.location = location;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}


	

}
