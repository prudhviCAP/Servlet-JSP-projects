package com.igate.assignment.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.igate.assignment.dao.EmployeeDaoImpl;
import com.igate.assignment.dao.IEmployeeDao;
import com.igate.assignment.dto.Employee;
import com.igate.lab1.exception.MyException;

public class EmployeeServiceImpl implements IEmployeeService{
	boolean resId=false;
	boolean resName=false;
	boolean resDeptId=false;
	boolean resLocation=false;
	@Override
	public List<Employee> getDetails(String id, String text) throws MyException {
		// TODO Auto-generated method stub
		IEmployeeDao daoobj=new EmployeeDaoImpl();
		List<Employee> list=daoobj.getDetails(id, text);
		return list;
	}

	@Override
	public StringBuilder isValid(String id, String text) {
		// TODO Auto-generated method stub
		StringBuilder strBuild=new StringBuilder();
		if(id.equals("eid"))
		{
			resId=isValidId(text);
			if(resId==false)
			{
				strBuild.append("Enter proper id containg only 3digits\n ");

			}
		}
		if(id.equals("nameId"))
		{
			resName=isValidId(text);
			if(resName==false)
			{
				strBuild.append("Enter proper name containg only 3 characters\n ");

			}
		}
			
		if(id.equals("deptId"))
		{
			resDeptId=isValidDeptId(text);
			if(resDeptId==false)
			{
				strBuild.append("Enter proper department id containg only 2 digits\n ");

			}
		}
		if(id.equals("locId"))
		{
			resLocation=isValidLoc(text);
			if(resLocation==false)
			{
				strBuild.append("Enter proper name containg only 3 characters\n ");

			}
		}
		
		 
		return strBuild;
	}
	boolean isValidId(String text)
	{

		Pattern ptrn=Pattern.compile("^[0-9]{3}$");
		Matcher match=ptrn.matcher(text);
		if(match.find())
			return true;
		else
			return false;
	}
	boolean isValidText(String text)
	{

		Pattern ptrn=Pattern.compile("^[a-zA-Z]{3}$");
		Matcher match=ptrn.matcher(text);
		if(match.find())
			return true;
		else
			return false;
	}
	boolean isValidDeptId(String text)
	{

		Pattern ptrn=Pattern.compile("^[0-9]{2}$");
		Matcher match=ptrn.matcher(text);
		if(match.find())
			return true;
		else
			return false;
	}
	boolean isValidLoc(String text)
	{

		Pattern ptrn=Pattern.compile("^[a-zA-Z]{5,20}$");
		Matcher match=ptrn.matcher(text);
		if(match.find())
			return true;
		else
			return false;
	}


}
