package com.igate.hotelreservation.bean;

public class HotelReservationBean 
{
	private String roomType;
	private String name;
	private String arrivalDate;
	private String rooms;
	private String noOfNights;
	
	public HotelReservationBean(String roomType, String name,
			String arrivalDate, String rooms, String noOfNights) 
	{
		super();
		this.roomType = roomType;
		this.name = name;
		this.arrivalDate = arrivalDate;
		this.rooms = rooms;
		this.noOfNights = noOfNights;
	}
	
	public String getRoomType() 
	{
		return roomType;
	}
	public void setRoomType(String roomType)
	{
		this.roomType = roomType;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getArrivalDate()
	{
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate)
	{
		this.arrivalDate = arrivalDate;
	}
	public String getRooms() 
	{
		return rooms;
	}
	public void setRooms(String rooms) 
	{
		this.rooms = rooms;
	}
	public String getNoOfNights()
	{
		return noOfNights;
	}
	public void setNoOfNights(String noOfNights) 
	{
		this.noOfNights = noOfNights;
	}
}
