package com.igate.hotelreservation.service;

public class HotelServiceImpl implements IHotelService
{
	@Override
	public void getConnection()
	{
		// TODO Auto-generated method stub
		
	}

}
