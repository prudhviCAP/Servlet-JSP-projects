package com.igate.lab5.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.lab5.bean.ItemBean;
import com.igate.lab5.service.AuctionServiceImpl;
import com.igate.lab5.service.IAuctionService;



@WebServlet("/SuccessController")
public class SuccessController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       


    public SuccessController() 
    {
        super();


    }




	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{


	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ItemBean item=null;
		
		IAuctionService service=new AuctionServiceImpl();
		Map<Integer,ItemBean> map=new HashMap<Integer,ItemBean>();
		map=service.getDetails();
		Iterator itr=map.values().iterator();
		PrintWriter out=response.getWriter();
		String name1= request.getParameter("usrname");
		out.print("Welcome!..."+name1);
		out.println("<body>");
		out.println("<table border='1'>");
		out.println("<tr>");
		out.println("<th>Item ID</th>");
		out.println("<th>Item Name</th>");
		out.println("<th>Item Price</th>");
		out.println("<th>Item Status</th>");
		out.println("</tr>");
		while(itr.hasNext())
		{
			item=(ItemBean) itr.next();
			int itemId=item.getItemId();
			String itemName=item.getItemName();
			int itemPrice=item.getItemPrice();
			String status=item.getStatus();
			
			out.println("<tr>");
			out.println("<td>"+itemId+"</td>");
			out.println("<td>"+itemName+"</td>");
			out.println("<td>"+itemPrice+"</td>");
			out.println("<td>"+"<a href='BiddingCart?id1="+itemId+"'>"+status+"</a></td>");
			out.println("</tr>");
		}
	
		
			
		
		
	}

}
