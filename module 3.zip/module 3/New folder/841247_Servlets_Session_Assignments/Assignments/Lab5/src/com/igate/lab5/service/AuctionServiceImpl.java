package com.igate.lab5.service;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.igate.lab5.bean.ItemBean;
import com.igate.lab5.dao.IAuctionDao;
import com.igate.lab5.dao.IAuctionDaoImpl;

public class AuctionServiceImpl implements IAuctionService
{
	IAuctionDao dao=new IAuctionDaoImpl();

	@Override
	public boolean getConnection(String username,String password)
	{
		
		boolean value=dao.getConnection(username,password);
		return value;
	}

	@Override
	public Map<Integer,ItemBean> getDetails()
	{
		Map<Integer,ItemBean> map=new HashMap<Integer,ItemBean>();
		map=dao.getDetails();
		return map;
	}

	@Override
	public Map<Integer, ItemBean> getItemsSelected(int itemId) 
	{
		Map<Integer,ItemBean>map1=new HashMap();
		map1=dao.getItemsSelected(itemId);
		return map1;
	}
}
