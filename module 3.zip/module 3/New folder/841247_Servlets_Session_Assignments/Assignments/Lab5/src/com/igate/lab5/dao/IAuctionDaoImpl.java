package com.igate.lab5.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.igate.lab5.bean.ItemBean;
import com.igate.lab5.util.DBUtilConnection;

public class IAuctionDaoImpl implements IAuctionDao 
{
	static Map<Integer,ItemBean> map1;
	@Override
	public boolean getConnection(String username,String password)
	{
		Connection con=null;
		PreparedStatement prepare=null;
		ResultSet res=null;
		con=DBUtilConnection.obtainConnection();
		System.out.println("connected");
		boolean result=false;
		try
		{
			String query1="SELECT username,password from Login where username=? and password=?";
			prepare=con.prepareStatement(query1);
				prepare.setString(1,username);
				prepare.setString(2,password);
				res=prepare.executeQuery();
				result=res.next();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Map<Integer,ItemBean> getDetails()
	{
		//Set<ItemBean> itemSet=new LinkedHashSet<ItemBean>();
		ItemBean bean;
		Map<Integer,ItemBean> map=new HashMap<Integer,ItemBean>();
		Connection con=null;
		PreparedStatement prepare=null;
		ResultSet res=null;
		con=DBUtilConnection.obtainConnection();
		System.out.println("connected");
		try
		{
			String query1="SELECT * from itemsforbid";
			prepare=con.prepareStatement(query1);
			res=prepare.executeQuery();
			while(res.next())
			{
				int itemId=res.getInt("itemid");
				String itemName=res.getString("itemname");
				int itemPrice=res.getInt("itemprice");
				String status=res.getString("status");
				bean=new ItemBean(itemId,itemName,itemPrice,status);
				map.put(itemId,bean);
			}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return map;
	}

	@Override
	public Map<Integer, ItemBean>  getItemsSelected(int itemId) 
	{
		ItemBean item=null;
		map1=new HashMap<Integer,ItemBean>();
		Connection con=null;
		PreparedStatement prepare=null;
		ResultSet res=null;
		con=DBUtilConnection.obtainConnection();
		try 
		{
			String query3="select * from itemsforbid where itemid=?";
			prepare=con.prepareStatement(query3);
			prepare.setInt(1, itemId);
			res=prepare.executeQuery();
			while(res.next()) 
			{
				int id=res.getInt("itemid");
				String itemName=res.getString("itemname");
				int price=res.getInt("itemprice");
				String status=res.getString("status");
				item=new ItemBean(id,itemName,price,status);
				map1.put(id, item);
			}
		} catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return map1;
	}
}

