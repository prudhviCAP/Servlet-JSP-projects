package com.igate.lab3.exception;

public class MyException extends Exception 
{
	public MyException(String msg)
	{
		super(msg);
	}
}
