package com.igate.lab3.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.iagte.lab3.util.DataBaseUtil;
import com.igate.lab3.bean.RegistrationBean;
import com.igate.lab3.exception.MyException;

public class RegistartionDaoImpl implements IRegistrationDAO
{
	@Override
	public void getConnection(RegistrationBean bean) 
	{
		Connection con=null;
		Statement statement = null;
		ResultSet rsSet = null;
		PreparedStatement prepare= null;
		try 
		{
			con = DataBaseUtil.obtainConnection();
			System.out.println("connected");
		
		String query1="INSERT into RegisteredUsers values(?,?,?)";
		prepare=con.prepareStatement(query1);
		prepare.setString(1, bean.getFirstName());
		prepare.setString(2, bean.getLastName());
		prepare.setString(3, bean.getPassword());
		prepare.executeUpdate();
		con.commit();
		
		}catch(SQLException e)
		{
			System.err.println(e);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}