package com.igate.lab3.service;

import com.igate.lab3.bean.RegistrationBean;

public interface IRegistrationService 
{
	public void getConnection(RegistrationBean bean);
}
