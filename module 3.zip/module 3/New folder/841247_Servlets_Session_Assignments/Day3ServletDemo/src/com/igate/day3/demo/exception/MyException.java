package com.igate.day3.demo.exception;

public class MyException extends Exception
{
	MyException(String msg)
	{
		super(msg);
	}
}
	