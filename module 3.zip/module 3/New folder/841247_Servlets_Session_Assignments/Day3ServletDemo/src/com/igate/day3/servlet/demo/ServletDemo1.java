package com.igate.day3.servlet.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.day3.demo.exception.MyException;

/**
 * Servlet implementation class ServletDemo1
 */
@WebServlet("/ServletDemo.do")
public class ServletDemo1 extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletDemo1() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		String username=request.getParameter("usrname");
		String age=request.getParameter("usrage");
		HttpSession session=request.getSession();
		
		/*RequestDispatcher req=getServletContext().getRequestDispatcher("/ViewServlet.view");
		session.setAttribute("name", username);
		req.forward(request, response);*/
		
		
		
		/*Pattern pattern=Pattern.compile("^[a-zA-Z]{5,20}$");
		Matcher match1=pattern.matcher(username);
		if(!match1.find())
		{
			req=request.getRequestDispatcher("ErrorServlet.error");
		}
		
		Pattern pattern1=Pattern.compile("^[0-9]{2}$");
		Matcher match2=pattern1.matcher(age);
		if(!match2.find())
		{
			req=request.getRequestDispatcher("ErrorServlet.error");
		}
			*/
		
		RequestDispatcher reqDis=getServletContext().getRequestDispatcher("/ViewServlet.view?name="+username);
		//RequestDispatcher req3=request.getRequestDispatcher("");
		//RequestDispatcher req1=getServletContext().getNamedDispatcher("ViewServlet");
		
		getServletContext().setAttribute("name",username);
		reqDis.forward(request, response);
		//request.setAttribute("uage","age" );
		
		//out.println("Sharath");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

}
