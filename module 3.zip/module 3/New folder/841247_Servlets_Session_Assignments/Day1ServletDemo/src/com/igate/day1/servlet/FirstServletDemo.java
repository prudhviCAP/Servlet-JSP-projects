package com.igate.day1.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServletDemo
 */
@WebServlet("/FirstDemo.view")
public class FirstServletDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServletDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	/*
    	//response.setContentType("text/html");
    	PrintWriter out=response.getWriter();
    	Date curDate=new Date();
    	out.println("Current date is : "+curDate);*/
    	doPost(request,response);
	}
   /* public void service(ServletRequest req, ServletResponse res)
    {
    	System.out.println("Service method: "+req.getContentType());
    }*/
    
   /* public void init()
    {
    	System.out.println("init invoked"+this.getServletName());
    }
    public void destroy()
    {
    	System.out.println("bye");
    }*/

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	
    	PrintWriter out=response.getWriter();
    	Date curDate=new Date();
    	String startHtml="<html><head><title>Welcome</title></head>"+
    			 "<body bgcolor='blue'>";
    			 String endHtml="</body></html>";
    	out.println(startHtml+"Current date is : "+curDate+endHtml);
	}

}
