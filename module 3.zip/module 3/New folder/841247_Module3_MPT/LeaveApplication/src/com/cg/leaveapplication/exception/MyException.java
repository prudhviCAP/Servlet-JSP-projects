package com.cg.leaveapplication.exception;

/**
 * Employee ID	:	841247
 * Class Name	:	MyException
 * Package		:	com.igate.leaveapplicaion.exception
 * Date			:	26/02/2016
 */

public class MyException extends Exception
{
	public MyException(String msg)
	{
		super(msg);
	}
}
