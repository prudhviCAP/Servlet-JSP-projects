package com.cg.leaveapplication.service;

import com.cg.leaveapplication.bean.UpdateDetailsBean;
import com.cg.leaveapplication.exception.MyException;

public interface ILeaveApplicationservice 
{
	public boolean isValid(String empid)throws MyException;
	public String getConnection(int empId)throws MyException;
	public int updateDetails(UpdateDetailsBean bean) throws MyException;
}
