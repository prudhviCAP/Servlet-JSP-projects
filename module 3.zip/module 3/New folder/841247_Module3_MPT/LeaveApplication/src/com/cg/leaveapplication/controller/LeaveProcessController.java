package com.cg.leaveapplication.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.leaveapplication.bean.UpdateDetailsBean;
import com.cg.leaveapplication.exception.MyException;
import com.cg.leaveapplication.service.ILeaveApplicationservice;
import com.cg.leaveapplication.service.LeaveApplicationServiceImpl;

/**
 * EmpID 		: 841247
 * Class Name 	: LeaveProcessController 
 * Package 		: com.cg.leaveapplication.controller
 * Date 		: 26/02/2016
 */

@WebServlet("/LeaveProcessController")
public class LeaveProcessController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LeaveProcessController() 
    {
        super();
    }



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String choice=request.getParameter("option");
		HttpSession session=request.getSession();
		String empId=request.getParameter("empidname");
		ILeaveApplicationservice service=new LeaveApplicationServiceImpl();
		
		
		//To Validate Employee ID and Select Employee name from Database 
		if(choice!=null&&choice.equalsIgnoreCase("Login"))
		{
			try 
			{
				boolean resIsbn=service.isValid(empId);
				if(resIsbn)
				{
					int employeeId =Integer.parseInt(empId);
					LocalDate date=LocalDate.now();
					LocalDate startDate=date.plusDays(1);
					
					session.setAttribute("employeeId",employeeId);
					session.setAttribute("startDate", startDate);
					String name=service.getConnection(employeeId);
					session.setAttribute("name",name);
					if(name!=null)
					{
						//The Employee Details are forwarded to the apply leave page
						request.getRequestDispatcher("view/applyleave.jsp").forward(request, response);
					}
				}
			
			}
			catch (MyException e) 
			{
				session.setAttribute("errMsg", e.getMessage());
				request.getRequestDispatcher("view/error.jsp").forward(request, response);
			}
		
		}
		
		//To Update the employee_leave_details table
		if(choice!=null&&choice.equalsIgnoreCase("Apply Leave"))
		{
			PrintWriter out=response.getWriter();
			String noOfDays=request.getParameter("daysname");
			int days=Integer.parseInt(noOfDays);
			String desc=request.getParameter("leavetxt");
			String name=(String) session.getAttribute("name");
			int eid=(int) session.getAttribute("employeeId");
			LocalDate startDate=(LocalDate) session.getAttribute("startDate");
			LocalDate endDate=startDate.plusDays(days);
			
			
			UpdateDetailsBean bean=new UpdateDetailsBean(eid, startDate, endDate, desc, days);
			try 
			{
				int res=service.updateDetails(bean);
				if(days<=0)
				{
					session.setAttribute("errMsg", "Invalid Days..Enter valid Days");
					request.getRequestDispatcher("view/error.jsp").include(request, response);
				}
				else
				{
					out.println("Welcome"+name);
					request.getRequestDispatcher("view/success.jsp").include(request, response);
				}
			} 
			catch (MyException e) 
			{
				session.setAttribute("errMsg", "Invalid Days..Enter valid Days");
				request.getRequestDispatcher("view/error.jsp").include(request, response);
			}
		}
	}
}
