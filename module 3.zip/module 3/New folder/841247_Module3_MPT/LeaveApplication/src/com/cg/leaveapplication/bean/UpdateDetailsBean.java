package com.cg.leaveapplication.bean;

import java.time.LocalDate;

/**
 * EmpID 		: 841247
 * Class Name 	: UpdatedetailsBean 
 * Package 		: com.cg.Updatedetails.bean 
 * Date 		: 26/02/2016
 */

public class UpdateDetailsBean
{
	public int getEid()
	{
		return eid;
	}
	public void setEid(int eid) 
	{
		this.eid = eid;
	}
	public LocalDate getStartDate() 
	{
		return startDate;
	}
	public void setStartDate(LocalDate startDate) 
	{
		this.startDate = startDate;
	}
	public LocalDate getEndDate() 
	{
		return endDate;
	}
	public void setEndDate(LocalDate endDate) 
	{
		this.endDate = endDate;
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public int getLeavesApplied() 
	{
		return leavesApplied;
	}
	public void setLeavesApplied(int leavesApplied)
	{
		this.leavesApplied = leavesApplied;
	}
	public UpdateDetailsBean(int eid, LocalDate startDate, LocalDate endDate,
			String description, int leavesApplied) 
	{
		super();
		this.eid = eid;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.leavesApplied = leavesApplied;
	}
	private int eid;
	private LocalDate startDate;
	private LocalDate endDate;
	private String description;
	private int leavesApplied;
	
}
